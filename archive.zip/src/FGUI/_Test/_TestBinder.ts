/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

import FGUI_TestMain from "./FGUI_TestMain";

export default class _TestBinder {
	public static bindAll():void {
		fgui.UIObjectFactory.setExtension(FGUI_TestMain.URL, FGUI_TestMain);
	}
}