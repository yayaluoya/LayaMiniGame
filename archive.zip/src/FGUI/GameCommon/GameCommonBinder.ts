/** This is an automatically generated class by FairyGUI. Please do not modify it. **/


export default class GameCommonBinder {
	public static bindAll():void {
	}
}