/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

import FGUI_initLoadUI from "./FGUI_initLoadUI";

export default class InitLoadBinder {
	public static bindAll():void {
		fgui.UIObjectFactory.setExtension(FGUI_initLoadUI.URL, FGUI_initLoadUI);
	}
}