/** This is an automatically generated class by FairyGUI. Please do not modify it. **/

import FGUI_EmptyScreenUI from "./FGUI_EmptyScreenUI";

export default class InitEmptyScreenBinder {
	public static bindAll():void {
		fgui.UIObjectFactory.setExtension(FGUI_EmptyScreenUI.URL, FGUI_EmptyScreenUI);
	}
}