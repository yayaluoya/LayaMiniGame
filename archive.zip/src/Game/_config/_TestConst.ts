// ！ 自动导出，请不要修改
//
/**
 * _TestConst const配置文件
 * ! 自动导出，不要修改和直接引用
 */
export namespace _TestConst {
    /** 配置表类型 */
    export const type: string = 'const';
    /** 数据类型 */
    export class DataType {
       /** 数值测试 */
        n: number;
       /** 数值测试2 */
        n2: number;
       /** 数值测试3 */
        n3: number;
       /** 字符串测试 */
        s: string;
       /** 字符串测试2 */
        s2: string;
       /** 字符串测试3 */
        s3: string;
       /** 布尔值测试 */
        b: boolean;
       /** 布尔值测试1 */
        b2: boolean;
       /** 布尔值测试2 */
        b3: boolean;
       /** 布尔值测试 */
        b4: boolean;
       /** 布尔值测试3 */
        b5: boolean;
       /** 布尔值测试4 */
        b6: boolean;
       /** 布尔值测试5 */
        b7: boolean;
       /** 其他类型测试 */
        o: any;
       /** 其他类型测试1 */
        o2: any;
       /** 其他类型测试2 */
        o3: any;
    }
    /** const数据列表 */
    export var data: _TestConst.DataType = null;
    /** 文件名字 */
    export const fileName: string = 'TestConst.json';
}
    