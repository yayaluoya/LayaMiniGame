import BaseData from "src/_T/Data/BaseData";

/**
 * 签到数据
 */
export default class SignData extends BaseData {
    //
}