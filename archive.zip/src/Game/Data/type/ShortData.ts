import BaseData from "src/_T/Data/BaseData";

/**
 * 临时数据
 */
export default class ShortData extends BaseData { }