import BaseData from "src/_T/Data/BaseData";

/**
 * 主要数据
 */
export default class MainData extends BaseData {
    //
}