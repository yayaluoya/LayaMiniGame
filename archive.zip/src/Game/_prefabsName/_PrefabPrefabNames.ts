/**
 * Prefab 场景的所有预制体名字
 * ! 此文件是Unity自动导出的，不要修改，也不要直接依赖。
 */
export default class _PrefabPrefabName {
    public static readonly Cube: string = 'Cube';
    public static readonly Sphere: string = 'Sphere';

}

/**
 * Prefab 场景的所有预制体名字分类
 */
export class _PrefabPrefabClass {
    
}
//