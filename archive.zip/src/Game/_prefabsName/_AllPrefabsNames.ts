/**
 * 所有预制体名字
 * ! 此文件是Unity自动导出的，不要修改，也不要直接依赖。
 */
export default class _AllPrefabsNames {
    public static readonly Cube: string = 'Cube';
    public static readonly Sphere: string = 'Sphere';

}