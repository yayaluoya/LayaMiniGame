/**
 * 所有场景对应的预制体名字列表
 * ! 此文件是Unity自动导出的，不要修改，也不要直接依赖。
 */
export enum _EAllScenePrefabsNames {
    Prefab = '@Cube@@Sphere@',

}
//