/**
 * 常量配置
 */
export default class _ConstConfig {
    /** fgui相关 */
    public static FGUI = {
        /** 包后缀 */
        packageFileExtension: 'bin',
    };
}