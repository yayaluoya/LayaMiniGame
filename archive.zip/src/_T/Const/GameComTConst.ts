/**
 * 项目公共工具常量类
 */
export class GameComTConst {
    //
}