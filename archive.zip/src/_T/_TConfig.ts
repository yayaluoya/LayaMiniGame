/**
 * 框架配置文件
 */
export default class _TConfig {
    /** 名字 */
    public static Name: string = "LayaMiniGame";
    /** 中文名字 */
    public static ZHName: string = "LayaBox小游戏";
    /** 版本 */
    public static Versions: string = "0.0.0.1";
}