/**
 * 配置表接口
 */
export interface IConfigData {
    /** 数据 */
    data: any;
    /** 是否压缩 */
    zip: boolean;
}