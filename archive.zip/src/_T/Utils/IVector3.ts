/**
 * 向量接口
 */
export interface IVector3 {
    x: number,
    y: number,
    z: number,
}