/**
 * fgui配置
 */
export enum EFGUIConst {
    /** 显示动效 */
    showAni = 'm__show',
    /** 隐藏动效 */
    hideAni = 'm__hide',
}