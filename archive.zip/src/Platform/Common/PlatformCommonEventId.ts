/**
 * 平台公共事件
 */
export enum PlatformCommonEvent {
    PAUSE_AUDIO = "PAUSE_AUDIO",
    RESUM_AUDIO = "RESUM_AUDIO",
    AD_CONFIG_GETTED = "AD_CONFIG_GETTED",
    SELF_AD_INITED = "SELF_AD_INITED",
}