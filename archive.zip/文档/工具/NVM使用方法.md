# NVM使用方法

    nvm // 会提示nvw下的相关命令
    nvm ls // 查看已安装node版本
    nvm install vXX // 安装对应vXX版本的node
    nvm uninstall> vXX // 卸载对应vXX版本的node
    nvm use xxx // 选择使用XXX版本

    推荐使用 node v11.11.0 高版本不能使用layaAir编译
    如果只用webpack编译建议使用 node v12.21.0

## NVM安装方法

    先卸载Node
    下载nvm并安装 (推荐使用nvm-setup.zip)
    https://github.com/coreybutler/nvm-windows/releases

## 踩坑
    当已经安装了一个版本在使用另一个版本时可能会出错，把全部版本删了就没事了。
