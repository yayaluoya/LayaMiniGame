/**
 * Com处理类
 */
export default class ComDispose {
    /**
     * 初始化
     */
    public static init() { }
}