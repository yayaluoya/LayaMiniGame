/**
 * 响应状态码
 */
export enum EResponseCode {
    /** 成功 */
    com = 1,
    /** 失败 */
    lose = 2,
}