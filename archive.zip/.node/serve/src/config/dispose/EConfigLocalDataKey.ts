/**
 * 配置表本地数据索引
 */
export enum EConfigLocalDataKey {
    /** 配置表信息数据 */
    excelInfoData = 'excelInfoData',
}