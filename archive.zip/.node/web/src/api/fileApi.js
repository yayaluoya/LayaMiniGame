import rootApi from "./rootApi";

/**
 * 文件api
 */
const fileApi = {
    /** 上传文件 */
    uploadFile: rootApi + 'file/uploadFile',
};

export default fileApi;