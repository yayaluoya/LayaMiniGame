/**
 * 公共api
 */
const comApi = {
    //
};

export default comApi;