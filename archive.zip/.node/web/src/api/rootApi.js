/**
 * 根api路径
 */
const rootApi = 'http://localhost:3000/';

export default rootApi;