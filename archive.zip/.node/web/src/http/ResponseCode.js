/**
 * 响应状态码
 */
export default {
    /** 成功 */
    com: 1,
    /** 失败 */
    lose: 2,
}