<template>
    <div id="Background"></div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
#Background {
    width: 100%;
    height: 100%;
    position: absolute;
    background-color: #f9f9f9;
    z-index: -999;
}
</style>