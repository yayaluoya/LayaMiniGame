const chalk = require('chalk');
var moment = require('moment');
var cmd = require('node-cmd');

//时间格式化
// console.log(moment(Date.now()).format('YYYY-MM-DD HH:mm:ss'));

// console.log(chalk.magenta('----▷ 第'), chalk.green(` ${1000} `), chalk.magenta('次编辑完成'), ' 时间 ', chalk.red('出错啦 1'));
